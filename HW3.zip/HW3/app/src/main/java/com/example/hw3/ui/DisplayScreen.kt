package com.example.hw3.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.hw3.viewmodel.UserViewModel

@Composable
fun DisplayScreen(viewModel: UserViewModel) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        // Show username
        Text(text = "Username: ${viewModel.username}")

        Spacer(modifier = Modifier.height(20.dp))

        // Show saved image
        viewModel.imageUri?.let { uri ->
            Image(
                painter = rememberAsyncImagePainter(uri),
                contentDescription = "Saved Image",
                modifier = Modifier.size(200.dp)
            )
        }
    }
}
