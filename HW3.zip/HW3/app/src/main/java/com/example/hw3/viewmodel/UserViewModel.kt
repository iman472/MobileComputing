package com.example.hw3.viewmodel

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.net.toUri
import androidx.lifecycle.ViewModel
import com.example.hw3.repository.UserRepository
import java.io.File
import java.io.IOException

class UserViewModel(private val repository: UserRepository) : ViewModel() {

    var username by mutableStateOf("")
        private set

    var imageUri by mutableStateOf<Uri?>(null)
        private set

    init {
        loadUserData()
    }

    private fun loadUserData() {
        val user = repository.getUser()

        if (user != null) {
            username = user.username

            if (user.imagePath != null) {
                val file = File(user.imagePath)
                if (file.exists()) {
                    imageUri = file.toUri()
                }
            }
        }
    }

    fun updateUsername(newName: String) {
        username = newName
        saveUser()
    }

    fun saveUser() {
        repository.saveUser(username, imageUri?.path)
    }

    fun onImagePicked(context: Context, uri: Uri) {
        copyImageToInternalStorage(context, uri)?.let { savedPath ->
            imageUri = File(savedPath).toUri()
            repository.saveUser(username, savedPath)
        }
    }

    private fun copyImageToInternalStorage(context: Context, sourceUri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(sourceUri) ?: return null
            val file = File(context.filesDir, "profile_image.jpg")
            inputStream.use { input ->
                file.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            file.absolutePath
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }
}
