package com.example.hw3

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.room.Room
import com.example.hw3.data.UserDatabase
import com.example.hw3.repository.UserRepository
import com.example.hw3.ui.DisplayScreen
import com.example.hw3.ui.MainScreen
import com.example.hw3.viewmodel.UserViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(
            applicationContext,
            UserDatabase::class.java,
            "user_db"
        ).allowMainThreadQueries().build()

        val repository = UserRepository(db.userDao())

        setContent {

            val viewModel = remember { UserViewModel(repository) }

            val imagePickerLauncher =
                rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.PickVisualMedia()
                ) { uri: Uri? ->
                    if (uri != null) {
                        viewModel.onImagePicked(this@MainActivity, uri)
                    }
                }

            val pickImage: () -> Unit = {
                imagePickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            }

            MaterialTheme {
                Surface {
                    AppNavigation(viewModel, pickImage)
                }
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: UserViewModel, pickImage: () -> Unit) {
    var showDisplay by remember { mutableStateOf(false) }

    if (showDisplay) {
        DisplayScreen(viewModel)
    } else {
        MainScreen(
            viewModel = viewModel,
            onPickImage = pickImage,
            onNext = { showDisplay = true }
        )
    }
}
