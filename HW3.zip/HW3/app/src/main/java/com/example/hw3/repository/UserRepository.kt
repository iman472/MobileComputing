package com.example.hw3.repository

import com.example.hw3.data.UserDao
import com.example.hw3.data.UserEntity

class UserRepository(private val dao: UserDao) {

    fun getUser(): UserEntity? = dao.getUser()

    fun saveUser(username: String, imagePath: String?) {
        dao.saveUser(UserEntity(0, username, imagePath))
    }
}
