package com.example.hw3.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.hw3.viewmodel.UserViewModel

@Composable
fun MainScreen(
    viewModel: UserViewModel,
    onPickImage: () -> Unit,
    onNext: () -> Unit
) {
    var username by remember { mutableStateOf(viewModel.username) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        // Username input
        OutlinedTextField(
            value = username,
            onValueChange = {
                username = it
                viewModel.updateUsername(it)
            },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Pick Image button
        Button(onClick = { onPickImage() }) {
            Text("Pick Image")
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Show selected image
        viewModel.imageUri?.let { uri ->
            Image(
                painter = rememberAsyncImagePainter(uri),
                contentDescription = "Selected Image",
                modifier = Modifier.size(150.dp)
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Save and go to next screen
        Button(onClick = {
            viewModel.saveUser()
            onNext()
        }) {
            Text("Save and Continue")
        }
    }
}
