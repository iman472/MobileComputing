package com.example.myweatherapp

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class WeatherViewModel : ViewModel() {

    val weatherData = mutableStateOf<WeatherResponse?>(null)
    val forecastData = mutableStateOf<ForecastResponse?>(null)

    // PUT YOUR KEY HERE
    private val apiKey = "YOUR_API_KEY_HERE"

    fun fetchWeather(city: String) {
        viewModelScope.launch {
            try {
                // Call current weather
                val weatherResponse = RetrofitInstance.api.getWeather(city, apiKey)
                weatherData.value = weatherResponse

                // Call forecast
                val forecastResponse = RetrofitInstance.api.getForecast(city, apiKey)
                forecastData.value = forecastResponse
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}