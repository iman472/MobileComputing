package com.example.myweatherapp

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                WeatherScreen()
            }
        }
    }
}

@Composable
fun WeatherScreen() {
    val context = LocalContext.current
    val sharedPref = remember { context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE) }

    var city by remember { mutableStateOf(sharedPref.getString("last_city", "") ?: "") }
    var currentTemp by remember { mutableStateOf<Double?>(null) }
    var forecast by remember { mutableStateOf<List<ForecastItem>>(emptyList()) }
    var showDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val apiKey = "fa9e0c44a493dc229bb55971842d326e"

    val loadWeather = { cityName: String ->
        scope.launch(Dispatchers.IO) {
            try {
                sharedPref.edit().putString("last_city", cityName).apply()
                val current = RetrofitInstance.api.getWeather(cityName, apiKey)
                currentTemp = current.main.temp
                val forecastResponse = RetrofitInstance.api.getForecast(cityName, apiKey)

                // Filtering for 5 days (one record per day at 12:00)
                forecast = forecastResponse.list
                    .filter { it.dt_txt.contains("12:00:00") }
                    .take(5)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    LaunchedEffect(Unit) {
        if (city.isNotEmpty()) {
            loadWeather(city)
        }
    }

    if (showDialog) {
        CityListDialog(
            onCitySelected = { selectedCity ->
                city = selectedCity
                showDialog = false
                loadWeather(selectedCity)
            },
            onDismiss = { showDialog = false }
        )
    }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = city,
            onValueChange = { city = it },
            label = { Text("Search City") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                IconButton(onClick = { if (city.isNotEmpty()) loadWeather(city) }) {
                    Icon(Icons.Default.Search, contentDescription = null)
                }
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { if (city.isNotEmpty()) loadWeather(city) },
                modifier = Modifier.weight(1f)
            ) {
                Text("Refresh")
            }

            OutlinedButton(
                onClick = { showDialog = true },
                modifier = Modifier.weight(1f)
            ) {
                Text("Pick City")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        currentTemp?.let {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Current Weather in ${city.uppercase()}", style = MaterialTheme.typography.labelLarge)
                    Text("$it°C", style = MaterialTheme.typography.headlineLarge)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (forecast.isNotEmpty()) {
            Text("5-Day Forecast (at 12:00):", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn {
                items(forecast) { item ->
                    Card(
                        modifier = Modifier
                            .padding(vertical = 4.dp)
                            .fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.dt_txt.substring(0, 10))
                            Text("${item.main.temp}°C")
                            Text(item.weather[0].main)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CityListDialog(onCitySelected: (String) -> Unit, onDismiss: () -> Unit) {
    var searchQuery by remember { mutableStateOf("") }
    val allCities = listOf(
        "Tehran", "Mashhad", "Isfahan", "Tabriz", "Shiraz", "London",
        "New York", "Tokyo", "Paris", "Berlin", "Dubai", "Istanbul",
        "Moscow", "Madrid", "Rome", "Seoul", "Sydney", "Toronto",
        "Rio de Janeiro", "Cairo", "Mumbai", "Beijing", "Amsterdam", "Vienna"
    ).sorted()

    val filteredCities = allCities.filter { it.contains(searchQuery, ignoreCase = true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select a City") },
        text = {
            Column {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Filter cities...") },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    singleLine = true
                )

                Box(modifier = Modifier.height(300.dp)) {
                    LazyColumn {
                        items(filteredCities) { cityName ->
                            ListItem(
                                headlineContent = { Text(cityName) },
                                modifier = Modifier.clickable { onCitySelected(cityName) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}